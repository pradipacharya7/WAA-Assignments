package com.lab_10.solution.service;

import org.springframework.stereotype.Service;


public interface AddressService {

}
