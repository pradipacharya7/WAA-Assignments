package com.employeevalid.employeevalid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeevalidApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeevalidApplication.class, args);
    }

}
