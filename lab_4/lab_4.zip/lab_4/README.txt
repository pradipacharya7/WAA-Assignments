Iteration Plan
1.Analyse the architecture of the Proble
2.Replaced the jsp tags by spring tag library
3.Used @ModelAttribute as method parameter and placed in method as well
4.Used message tag to replace label field by adding fiel name in messages.properties fiel

Comments
This assignment made me more clear about the spring tag libraries(message,url,form,select etc) and their uses along with the use of @ModelAttribute annotation 