Iteration PLans
1.Registration form is created
2.Anotations(@NotNull, @DateTimePattern,@Min,@Max,@NotBlank,@Size,@Email etc) are added to the filed in the Student model according to requirement 
3.@Valid is added to the post methd before @MOdelAttribute
4.Condition added to the method 
5.Message were added to the errorMessages.properties 
6.Error tag is added to the front page
7. Output is generated as expected 

Comments 
1.Learned Bean Validation in Spring using hybernate validation Dependency.
