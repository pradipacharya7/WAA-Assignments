
Iteration Plan(Problem 1)

1.First of all design an architecture for converting given code into MVC 
2.Secondly, I created calculator as Model, 3 view jsp pages(index,calculator and result) and a controller(Calculator controller)
3.Finally wrote code and logic for adding and multiplying two numbers given by users.(I wrote logic in controller @Post method at Servlet)
Time:It took me arround 2 hours to get final result
Comment: Assignment is good for revision of servlet and JSP.

Iteration Plan(Problem 2)

1.Created a new project using Maven in intellij
2.Added framework from the demo project provided.
3.Added controller Calc controller, three views inside WEB-INF file, a model as before
4.Implemented Validation before calculation and showed error message if any in the front end where values come from the client using POST method.
5.Implemented logic in the same method is no error occurs.
6.Finally got outpust as expected.

Time:Honestly, I could not even run the project for a whole day. Finally removed the space for the Tomcat path and got the output. Took a lot of time to implement framework for the first time.
Comment: Assignment is great to understand how actually the Spring MVC framework works internally.

