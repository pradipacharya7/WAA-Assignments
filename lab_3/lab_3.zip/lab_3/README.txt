Iteration Plan(Problem 1)
1.Created a spring project from the scratch 
2.Created aArchitecture required i.e MVC (calculator as model, three view pages in the front end and a controller)
4.Every Request is mapped at controller with the url
5.Logic is implemented in a method where the form values are got taken using POST method
6.Finally, expected output was generated 

Actual Time: Arround 1 hour
Comments: This lab gave me more knowledge in using spring MVC and how actually it works and appropriate use of @Annotations like @RequestMapping, @COntroller


Iteration Plan(Problem 2)
1.Created a spring project from the scratch
2.Created Architecture(MVC) including hard coded data layer.
3.Only one controller was used to deal with incoming requests.
4.Authentication Business logic was used in controller in my case 
5. Expected output was generated

Actual Time:Arround 1 hour
Comments: This lab provided me with the more knowledge about the Spring framework and appropriate use of @Annotations like @Controler, @Repositories,@ Component etc