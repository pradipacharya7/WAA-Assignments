package com.example.lab_9.lab_9.controller;

import com.example.lab_9.lab_9.domain.dto.DomainError;
import com.example.lab_9.lab_9.domain.dto.DomainErrors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.List;

@ControllerAdvice

public class  ExceptionController {

    @Autowired
    private MessageSource messageSource;

	@Autowired
    MessageSourceAccessor messageAccessor;
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
       public DomainErrors handleException(MethodArgumentNotValidException exception) {
        System.out.println("here");
        List<FieldError> fieldErrors = exception.getBindingResult().getFieldErrors();
   
        DomainErrors errors = new DomainErrors();
        errors.setErrorType("ValidationError");
        for (FieldError fieldError : fieldErrors) {
         	DomainError error = new DomainError( messageAccessor.getMessage(fieldError));
                       errors.addError(error);
        }
         
         return errors;
    }
     
  
  
}