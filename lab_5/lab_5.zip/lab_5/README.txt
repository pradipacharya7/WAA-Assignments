Lab_5
Problem 1
Iteration PLan
1. Lab_3 calculator is upgraded to PRG pattern. Where every request after post is redirect to a get method to get view so prevent resubmission of the form.
2. redirect.addFlushAttribute is used to preserve the value during the redirection.
3. A string as a greeting is forwared to the view using addFlushAttribute.
4. Hence expected output is generated.

Problem 2
Iteration PLan
1.Lab 3 Starbuck is upgraded using session scope in the application
3.Authentication is applied according to the Session value.
4.User name is displayed in the advice and display .jsp page using session 
5.log out is impemented using SessionStatus stutas to status.setcomplete()
6.Hence Expected output is generated 